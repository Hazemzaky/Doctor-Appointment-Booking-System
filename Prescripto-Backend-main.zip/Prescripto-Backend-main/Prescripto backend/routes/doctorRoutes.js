import express from'express'
import { doctorList } from '../backend/controllers/doctorcontrollers.js'

const doctorRouter =express.Router()

dictorRouter.get('/list',)

export default doctorRouter